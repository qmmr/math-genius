$(function(){
	$("#jquery-test").html("jQuery is loaded");
});